/* buildCns_multiViews_multiTrees.js
 * No CLI args. Run inside WinCC OA Node.js manager.
 * View  = first s="..." segment
 * Tree  = second s="..." segment
 * Leaf  = last remaining segment (attach DPE)
 */

const { WinccoaManager, WinccoaCnsTreeNode } = require('winccoa-manager');

const CNS_SEPARATOR = '.';

const sanitizeId = s => String(s).replace(/[.:,;*?\[\]{}$@"'\\\/]+/g, '_').trim();
const joinNode   = (parent, child) => (parent.endsWith(':') ? parent + child : parent + '.' + child);

// Extract quoted tokens from the s=... part → ["cmFlowMonitoringDB","FI100","HMI","mtpData","V"]
function quotedSegmentsFromS(ref) {
  if (!ref) return [];
  const m = String(ref).match(/(?:^|;)s=([^;]+)(?:;|$)/i);
  if (!m) return [];
  const sVal = m[1];
  const segs = [];
  const re = /"((?:[^"]|"")*)"/g; // handle doubled quotes
  let x;
  while ((x = re.exec(sVal)) !== null) segs.push(x[1].replace(/""/g, '"'));
  // Fallback if no explicit quotes
  return segs.length ? segs : sVal.split('.').map(t => t.replace(/^"|"$/g, '')).filter(Boolean);
}

(async () => {
  const winccoa = new WinccoaManager();

  // System path prefix for views
  const systemName = winccoa.getSystemName(); // e.g. "System1:"
  const sysNoColon = systemName.endsWith(':') ? systemName.slice(0, -1) : systemName;

  // Caches
  const ensuredViews = new Set();           // `${sysNoColon}.${viewId}:`
  const ensuredTrees = new Set();           // `${viewPath}.${treeId}`

  async function ensureView(viewLabel) {
    const viewId = sanitizeId(viewLabel);
    const viewPath = `${sysNoColon}.${viewId}:`;
    if (!ensuredViews.has(viewPath)) {
      if (!(await winccoa.cns_viewExists(viewPath))) {
        await winccoa.cnsCreateView(viewPath, viewLabel, CNS_SEPARATOR);
      }
      ensuredViews.add(viewPath);
    }
    return viewPath;
  }

  async function ensureTree(viewPath, treeLabel) {
    const treeId = sanitizeId(treeLabel);
    const treePath = joinNode(viewPath, treeId);
    if (!ensuredTrees.has(treePath)) {
      if (!(await winccoa.cns_treeExists(treePath))) {
        // Both parameters MUST be strings: (id, displayName)
        const tree = new WinccoaCnsTreeNode(treeId, treeLabel);
        await winccoa.cnsAddTree(viewPath, tree);
      }
      ensuredTrees.add(treePath);
    }
    return treePath;
  }

  const dpes = winccoa.dpNames('*.*');
  let linked = 0, skipped = 0;

  for (const dpe of dpes) {
    try {
      // Consider only distributed / driver-backed DPEs
      const dist = await winccoa.dpGet(dpe + ':_distrib.._type');
      if (!dist || Number(dist) === 0) { skipped++; continue; }

      const ref = await winccoa.dpGet(dpe + ':_address.._reference');
      const segs = quotedSegmentsFromS(ref);
      if (segs.length < 2) { // need at least [view, tree]
        console.warn(`Skip ${dpe}: not enough segments in s=... (${segs.join('/')})`);
        skipped++; continue;
      }

      const viewLabel = segs[0];
      const treeLabel = segs[1];

      const viewPath = await ensureView(viewLabel);
      const rootPath = await ensureTree(viewPath, treeLabel);

      // Remaining segments → nodes; last = leaf (attach DPE)
      let tail = segs.slice(2);
      if (tail.length === 0) {
        // If there are only two segments, create a single node under the tree as the leaf
        tail = [treeLabel];
      }

      let parent = rootPath;
      for (let i = 0; i < tail.length; i++) {
        const label = tail[i];
        const nodeId = sanitizeId(label);
        if (!nodeId) continue;

        const nodePath = joinNode(parent, nodeId);
        const isLeaf = i === tail.length - 1;

        const exists = await winccoa.cns_nodeExists(nodePath);
        if (!exists) {
          await winccoa.cnsAddNode(parent, nodeId, label, isLeaf ? dpe : '');
        } else if (isLeaf) {
          // Reattach DPE at leaf (idempotent in many setups)
          await winccoa.cnsAddNode(parent, nodeId, label, dpe);
        }
        parent = nodePath;
      }

      linked++;
    } catch (e) {
      console.error(`Failed for DPE "${dpe}":`, e?.message ?? e);
      skipped++;
    }
  }

  console.log(`Done. Linked ${linked}/${dpes.length} DPEs. Skipped ${skipped}.`);
  winccoa.exit();
})().catch(err => {
  console.error(err);
  process.exit(1);
});
