const {  WinccoaManager } = require ('winccoa-manager');
const { WinccoaCtrlScript } = require ('winccoa-manager');
const { WinccoaCtrlType } = require ('winccoa-manager');
const winccoa = new WinccoaManager();

const ctrlCode = `double simpleArgs(int x, double y, string s)
{
  return (x * y) + s.length();
}`;
let testFunction = async () => {
  //const script = new WinccoaCtrlScript(winccoa, ctrlCode, 'simple argument');
  const script = await WinccoaCtrlScript.fromFile(winccoa, fileName = 'test', "simpleArgs");
  /*let res = await script.start(
  'main',
  [12, 34.56, 'some text'],
  [WinccoaCtrlType.int, WinccoaCtrlType.double, WinccoaCtrlType.string]
);*/

  let res = await script.start(
  'main',
  [],
  []);
  console.log(res);
}

winccoa.dpSet("System1:PEA|PLC_1|cmFlowMonitoringDB_FI100AnaMon.OSLevel", 1);
console.log("1111");
testFunction();