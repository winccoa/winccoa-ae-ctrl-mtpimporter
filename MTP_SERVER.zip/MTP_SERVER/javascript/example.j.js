const {
  WinccoaCtrlScript,
  WinccoaCtrlType,
  WinccoaManager,
} = require ('winccoa-manager');
const winccoa = new WinccoaManager();

const ctrlCode = `double simpleArgs(int x, double y, string s)
{
  return (x * y) + s.length();
}`;
const script = new WinccoaCtrlScript(winccoa, ctrlCode, 'simple argument');
const result = await script.start(
  'simpleArgs',
  [12, 34.56, 'some text'],
  [WinccoaCtrlType.int, WinccoaCtrlType.double, WinccoaCtrlType.string]
);
console.log(result);